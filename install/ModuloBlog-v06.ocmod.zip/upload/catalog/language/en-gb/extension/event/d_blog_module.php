<?php 

$_['text_blog']                      = 'Blog';