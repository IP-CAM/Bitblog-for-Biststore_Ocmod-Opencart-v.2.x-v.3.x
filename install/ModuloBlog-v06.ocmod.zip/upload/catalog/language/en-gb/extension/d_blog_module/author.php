<?php
$_['text_error']        = 'Author not found!';
$_['text_review']       = 'comments';
$_['text_views']        = 'views';
$_['text_read_more']    = 'read more ⟶';
$_['text_tags']       	= 'tags:';

$_['text_edit']         = 'Edit';