<?php
// Text
$_['heading_title']     = 'Our Blog';
$_['description']       = 'Description';
$_['meta_title']        = 'Our Blog';
$_['meta_description']  = 'meta_description';
$_['meta_keyword']      = 'meta_keyword';


$_['text_edit']         = 'Edit';
$_['text_categories']   = 'Categories';
$_['text_read_more']    = 'read more ⟶';
$_['text_review']       = 'comments';
$_['text_views']        = 'views:';
$_['text_tags']       	= 'tags:';
$_['text_post']         = 'Post';
$_['text_error']        = 'Category not found!';
$_['text_empty']        = 'There are no posts to list in this category.';
$_['text_quantity']     = 'Qty:';
$_['text_manufacturer'] = 'Brand:';
$_['text_model']        = 'Post name:';
$_['text_points']       = 'Reward Points:';
$_['text_price']        = 'Price:';
$_['text_tax']          = 'Ex Tax:';
$_['text_compare']      = 'Product Compare (%s)';
$_['text_sort']         = 'Sort By:';
$_['text_default']      = 'Default';
$_['text_name_asc']     = 'Name (A - Z)';
$_['text_name_desc']    = 'Name (Z - A)';
$_['text_rating_asc']   = 'Rating (Lowest)';
$_['text_rating_desc']  = 'Rating (Highest)';
$_['text_limit']        = 'Show:';

$_['text_restricted_access']   = 'Restricted access';
$_['text_login']			   = 'Please <a href="index.php?route=account/login">login</a> to receive access to this content';
$_['text_contact_admin']       = 'Please <a href="index.php?route=information/contact">contact</a> the site administrator to receive access to this content';
$_['text_error']               = 'Category not found!';