<?php
// Text
$_['text_search']              = 'Search';


$_['text_posted_by']           = 'Posted by';
$_['text_anonymous']           = 'Anonymous';
$_['text_on']                  = 'on';
$_['text_edit']                = 'Edit';

$_['text_tags']                = 'Tags:';
$_['text_error']               = 'Post not found!';
$_['text_payment_recurring']   = 'Payment Profile';
$_['text_day']                 = 'day';
$_['text_week']                = 'week';
$_['text_semi_month']          = 'half-month';
$_['text_month']               = 'month';
$_['text_year']                = 'year';
$_['text_restricted_access']   = 'Restricted access';
$_['text_login']			   = 'Please <a href="index.php?route=account/login">login</a> to receive access to this content';
$_['text_contact_admin']       = 'Please <a href="index.php?route=information/contact">contact</a> the site administrator to receive access to this content';
$_['restrict_access_label_group']       = 'Access only for member of group %';
$_['restrict_access_label_user']       = 'Access only for permited users';
