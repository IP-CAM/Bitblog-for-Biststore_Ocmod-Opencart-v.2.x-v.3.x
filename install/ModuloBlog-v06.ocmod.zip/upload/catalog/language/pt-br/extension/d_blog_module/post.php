<?php
// Text
$_['text_search']              = 'Buscar';


$_['text_posted_by']           = 'Postado por';
$_['text_anonymous']           = 'Anônimo';
$_['text_on']                  = 'na';
$_['text_edit']                = 'Editar';

$_['text_tags']                = 'Tags:';
$_['text_error']               = 'Postagem não encontrada!';
$_['text_payment_recurring']   = 'Perfil de Pagamento';
$_['text_day']                 = 'dia';
$_['text_week']                = 'semana';
$_['text_semi_month']          = 'meio mês';
$_['text_month']               = 'mês';
$_['text_year']                = 'ano';
$_['text_restricted_access']   = 'Acesso restrito';
$_['text_login']	       = 'Por favor <a href="index.php?route=account/login">login</a> para ter acesso a este conteúdo';
$_['text_contact_admin']       = 'Por favor <a href="index.php?route=information/contact">contate</a> o administrador do site para ter acesso a este conteúdo';
$_['restrict_access_label_group'] = 'Acesso apenas para membro do grupo %';
$_['restrict_access_label_user']  = 'Acesso apenas a usuários permitidos';
