<?php
$_['text_error']        = 'Autor não encontrado!';
$_['text_review']       = 'comentários';
$_['text_views']        = 'visualizações';
$_['text_read_more']    = 'ler mais ⟶';
$_['text_tags']       	= 'tags:';

$_['text_edit']         = 'Editar';