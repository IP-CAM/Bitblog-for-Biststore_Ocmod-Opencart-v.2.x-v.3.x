<?php
$_['d_blog_module_layout'] = array(
    'id' => 'grid',
    'name' => 'Grid',
    'description' => 'Use the layout grid option below to create any kind of layout with rows and columns.',
    'template' => 'extension/d_blog_module/layout_grid',
    'styles'=> array(),
    'scripts' => array()
);