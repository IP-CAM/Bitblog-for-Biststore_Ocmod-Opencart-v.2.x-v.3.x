<?php 

$_['text_blog']                      = 'Blog';
$_['text_blog_post']                 = 'Postagens';
$_['text_blog_category']             = 'Categorias';
$_['text_blog_review']               = 'Comentários';
$_['text_blog_author']               = 'Autor';
$_['text_blog_author_group']         = 'Grupo de Autor';
$_['text_blog_settings']             = 'Configurações';