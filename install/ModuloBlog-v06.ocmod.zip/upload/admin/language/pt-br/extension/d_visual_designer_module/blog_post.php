<?php
$_['text_title']             = 'Postagens no blog';
$_['text_description']       = 'Adicione suas postagens do módulo de blog';

$_['entry_title']            = 'Título';
$_['entry_mode']             = 'Digite postagens';
$_['entry_categories']       = 'Categorias do Blog';
$_['entry_posts']            = 'Postagens';

$_['text_latest']            = 'Mais recentes';
$_['text_featured']          = 'Destaque';
$_['text_popular']           = 'Popular';
$_['text_custom_products']   = 'Postagens Personalizadas';
$_['text_custom_categories'] = 'Categorias Personalizadas';