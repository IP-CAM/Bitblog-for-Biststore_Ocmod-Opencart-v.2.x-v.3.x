<?php
$_['entry_admin_style']     = 'Estilo de administrador';