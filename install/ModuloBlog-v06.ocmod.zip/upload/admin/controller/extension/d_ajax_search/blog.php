<?php
/*
 *
 */
class ControllerExtensionDAjaxSearchBlog extends Controller
{

}